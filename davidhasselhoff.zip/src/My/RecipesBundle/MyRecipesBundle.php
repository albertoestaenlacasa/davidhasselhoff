<?php

namespace My\RecipesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MyRecipesBundle extends Bundle
{
}
