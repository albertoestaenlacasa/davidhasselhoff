<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_c432478bdf0e42dacc6fe9fa770018ad7d21c6f5dcf903e86be74a7ad5b0f601 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_480c1b14fb69ae6415f4ef1fcb2467f60a18d73e24ef8a848b0c314ebe075fdb = $this->env->getExtension("native_profiler");
        $__internal_480c1b14fb69ae6415f4ef1fcb2467f60a18d73e24ef8a848b0c314ebe075fdb->enter($__internal_480c1b14fb69ae6415f4ef1fcb2467f60a18d73e24ef8a848b0c314ebe075fdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_480c1b14fb69ae6415f4ef1fcb2467f60a18d73e24ef8a848b0c314ebe075fdb->leave($__internal_480c1b14fb69ae6415f4ef1fcb2467f60a18d73e24ef8a848b0c314ebe075fdb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
