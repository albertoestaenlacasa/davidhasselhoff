<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_c398f15b0a747d0e4740d217dc1da53f188f8e1f282dfcd5e79187b3549858e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd0f686ed1764b7c7d032d44bfb977b2aece7f3ca0f1f924e035ddbb9a459139 = $this->env->getExtension("native_profiler");
        $__internal_cd0f686ed1764b7c7d032d44bfb977b2aece7f3ca0f1f924e035ddbb9a459139->enter($__internal_cd0f686ed1764b7c7d032d44bfb977b2aece7f3ca0f1f924e035ddbb9a459139_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_cd0f686ed1764b7c7d032d44bfb977b2aece7f3ca0f1f924e035ddbb9a459139->leave($__internal_cd0f686ed1764b7c7d032d44bfb977b2aece7f3ca0f1f924e035ddbb9a459139_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
