<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_808e4edd74f6bfdb0dd9cd4a93df72944210a0cc438a10923e057d42d24b4698 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80dd24d8b9e23b383a6e0b722437abf3cfc30f36f80c1dcfd7d44fccf3709806 = $this->env->getExtension("native_profiler");
        $__internal_80dd24d8b9e23b383a6e0b722437abf3cfc30f36f80c1dcfd7d44fccf3709806->enter($__internal_80dd24d8b9e23b383a6e0b722437abf3cfc30f36f80c1dcfd7d44fccf3709806_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_80dd24d8b9e23b383a6e0b722437abf3cfc30f36f80c1dcfd7d44fccf3709806->leave($__internal_80dd24d8b9e23b383a6e0b722437abf3cfc30f36f80c1dcfd7d44fccf3709806_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_0847345124540e9fbf20635441b51ec689630163f1944b5227c3e85dbfedd5c8 = $this->env->getExtension("native_profiler");
        $__internal_0847345124540e9fbf20635441b51ec689630163f1944b5227c3e85dbfedd5c8->enter($__internal_0847345124540e9fbf20635441b51ec689630163f1944b5227c3e85dbfedd5c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_0847345124540e9fbf20635441b51ec689630163f1944b5227c3e85dbfedd5c8->leave($__internal_0847345124540e9fbf20635441b51ec689630163f1944b5227c3e85dbfedd5c8_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
