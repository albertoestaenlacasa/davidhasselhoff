<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_0caabf7344f160248631998e6e70a11e3945649817953886ef3eb53f6095ccf4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9e1ee2532587aa2c0515e038dc08399145a16e74d1f7f236c314f5fc98a4b00 = $this->env->getExtension("native_profiler");
        $__internal_f9e1ee2532587aa2c0515e038dc08399145a16e74d1f7f236c314f5fc98a4b00->enter($__internal_f9e1ee2532587aa2c0515e038dc08399145a16e74d1f7f236c314f5fc98a4b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_f9e1ee2532587aa2c0515e038dc08399145a16e74d1f7f236c314f5fc98a4b00->leave($__internal_f9e1ee2532587aa2c0515e038dc08399145a16e74d1f7f236c314f5fc98a4b00_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
