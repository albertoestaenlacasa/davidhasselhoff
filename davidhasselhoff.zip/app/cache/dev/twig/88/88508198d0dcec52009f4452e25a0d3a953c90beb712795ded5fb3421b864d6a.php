<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_30e611367b0d28d748870e6aff0db160b39cb6a1bd3744cacad3fbc6aeec83b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb5cc72bf9c1830b273cda6bd9d49c1dfc6359ae07e7032f278f36c05c559f2a = $this->env->getExtension("native_profiler");
        $__internal_eb5cc72bf9c1830b273cda6bd9d49c1dfc6359ae07e7032f278f36c05c559f2a->enter($__internal_eb5cc72bf9c1830b273cda6bd9d49c1dfc6359ae07e7032f278f36c05c559f2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_eb5cc72bf9c1830b273cda6bd9d49c1dfc6359ae07e7032f278f36c05c559f2a->leave($__internal_eb5cc72bf9c1830b273cda6bd9d49c1dfc6359ae07e7032f278f36c05c559f2a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
