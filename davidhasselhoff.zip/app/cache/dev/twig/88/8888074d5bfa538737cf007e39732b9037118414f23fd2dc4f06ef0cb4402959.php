<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_7097c1a04eab91c7187aa1b29cc452d8816ee70f618dd1040bb4b406a6f6a42c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48d252395de4a6766c56ca1090006d07a08e9675f04f63cb7a9804b5ce50d9be = $this->env->getExtension("native_profiler");
        $__internal_48d252395de4a6766c56ca1090006d07a08e9675f04f63cb7a9804b5ce50d9be->enter($__internal_48d252395de4a6766c56ca1090006d07a08e9675f04f63cb7a9804b5ce50d9be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_48d252395de4a6766c56ca1090006d07a08e9675f04f63cb7a9804b5ce50d9be->leave($__internal_48d252395de4a6766c56ca1090006d07a08e9675f04f63cb7a9804b5ce50d9be_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
