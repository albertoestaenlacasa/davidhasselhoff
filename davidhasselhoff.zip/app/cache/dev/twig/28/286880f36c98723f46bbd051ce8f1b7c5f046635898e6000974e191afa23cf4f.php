<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_38fe49bca7c9645d152d60cd805e4e4c9ab1555d722609f550c42873aabbc545 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c322d1c09ef678a71b5a98e5641222df6344eefdceabac5882127f9dc78b347 = $this->env->getExtension("native_profiler");
        $__internal_9c322d1c09ef678a71b5a98e5641222df6344eefdceabac5882127f9dc78b347->enter($__internal_9c322d1c09ef678a71b5a98e5641222df6344eefdceabac5882127f9dc78b347_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_9c322d1c09ef678a71b5a98e5641222df6344eefdceabac5882127f9dc78b347->leave($__internal_9c322d1c09ef678a71b5a98e5641222df6344eefdceabac5882127f9dc78b347_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
