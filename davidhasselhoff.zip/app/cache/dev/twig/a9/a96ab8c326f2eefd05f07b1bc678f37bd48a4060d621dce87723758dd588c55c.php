<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_676f169c7027f7635d4c64a09bde58805f58586834ead4cdf3a579d44c914261 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f8ba16f3f210f4f359d4679707801a878591503c72e64f87ccccf4dfd46dcbe = $this->env->getExtension("native_profiler");
        $__internal_3f8ba16f3f210f4f359d4679707801a878591503c72e64f87ccccf4dfd46dcbe->enter($__internal_3f8ba16f3f210f4f359d4679707801a878591503c72e64f87ccccf4dfd46dcbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_3f8ba16f3f210f4f359d4679707801a878591503c72e64f87ccccf4dfd46dcbe->leave($__internal_3f8ba16f3f210f4f359d4679707801a878591503c72e64f87ccccf4dfd46dcbe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
