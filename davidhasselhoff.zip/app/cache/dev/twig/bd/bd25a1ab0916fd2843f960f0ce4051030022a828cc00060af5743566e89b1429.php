<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_46a375bb19dfdd1769ef4e39c63bc9e259af14ee6902a1fa9af26e07b859f717 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d04b444f76562ca649023e6d5fe5fb460f83ffd346f1fca8d47e157e4dbfedb6 = $this->env->getExtension("native_profiler");
        $__internal_d04b444f76562ca649023e6d5fe5fb460f83ffd346f1fca8d47e157e4dbfedb6->enter($__internal_d04b444f76562ca649023e6d5fe5fb460f83ffd346f1fca8d47e157e4dbfedb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_d04b444f76562ca649023e6d5fe5fb460f83ffd346f1fca8d47e157e4dbfedb6->leave($__internal_d04b444f76562ca649023e6d5fe5fb460f83ffd346f1fca8d47e157e4dbfedb6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
