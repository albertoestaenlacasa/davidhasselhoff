<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_c1d0388cd70b260644dd7975cc1a12b047b63a641824a708b929eb26dc16f28e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d81a735312fa57fce0010c9ad640cb75e7943021ff0c0d11cbd2a67a626c2b98 = $this->env->getExtension("native_profiler");
        $__internal_d81a735312fa57fce0010c9ad640cb75e7943021ff0c0d11cbd2a67a626c2b98->enter($__internal_d81a735312fa57fce0010c9ad640cb75e7943021ff0c0d11cbd2a67a626c2b98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_d81a735312fa57fce0010c9ad640cb75e7943021ff0c0d11cbd2a67a626c2b98->leave($__internal_d81a735312fa57fce0010c9ad640cb75e7943021ff0c0d11cbd2a67a626c2b98_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
