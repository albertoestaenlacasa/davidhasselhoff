<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_dc97757e5c1347aae551c1cd81130a4b4f217c3fed8f818e12367562c3dfcbef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40c311abd9de8811897faeb2715b2f262b5cb7036e22a8f860255cf836dd61c9 = $this->env->getExtension("native_profiler");
        $__internal_40c311abd9de8811897faeb2715b2f262b5cb7036e22a8f860255cf836dd61c9->enter($__internal_40c311abd9de8811897faeb2715b2f262b5cb7036e22a8f860255cf836dd61c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_40c311abd9de8811897faeb2715b2f262b5cb7036e22a8f860255cf836dd61c9->leave($__internal_40c311abd9de8811897faeb2715b2f262b5cb7036e22a8f860255cf836dd61c9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
