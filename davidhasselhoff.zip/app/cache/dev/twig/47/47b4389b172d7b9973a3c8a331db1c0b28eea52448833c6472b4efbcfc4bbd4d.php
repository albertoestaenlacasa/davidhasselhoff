<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_2ac354600496ebcfd5c8a517a9d11ac09309fa9fb881a45ba9977ccc227dc757 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbae5b943645acadbff9818eedb3cbfb393391fc3b09a80b123e8693aca25c97 = $this->env->getExtension("native_profiler");
        $__internal_cbae5b943645acadbff9818eedb3cbfb393391fc3b09a80b123e8693aca25c97->enter($__internal_cbae5b943645acadbff9818eedb3cbfb393391fc3b09a80b123e8693aca25c97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_cbae5b943645acadbff9818eedb3cbfb393391fc3b09a80b123e8693aca25c97->leave($__internal_cbae5b943645acadbff9818eedb3cbfb393391fc3b09a80b123e8693aca25c97_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
