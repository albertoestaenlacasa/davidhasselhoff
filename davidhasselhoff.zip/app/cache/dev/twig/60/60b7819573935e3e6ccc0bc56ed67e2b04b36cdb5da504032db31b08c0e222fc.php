<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_e6b31a1ca8d3833cdf38c6c462e648d54920b05bf22bd91f5bb7f5c9b3d37d0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1a263a37517f5c28b4f5e2b16da4efd23c8bb505f3a28538379b640cfc155ff = $this->env->getExtension("native_profiler");
        $__internal_a1a263a37517f5c28b4f5e2b16da4efd23c8bb505f3a28538379b640cfc155ff->enter($__internal_a1a263a37517f5c28b4f5e2b16da4efd23c8bb505f3a28538379b640cfc155ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_a1a263a37517f5c28b4f5e2b16da4efd23c8bb505f3a28538379b640cfc155ff->leave($__internal_a1a263a37517f5c28b4f5e2b16da4efd23c8bb505f3a28538379b640cfc155ff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
