<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_828fc677ddf5cf9901b8b749e9b580b24df881a32b0302c261e29f250d59a3f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92cfa13d0a5ab00c3c86c56156e0c8ab9d4b617d75a0f604fb8c9fbc0cafe141 = $this->env->getExtension("native_profiler");
        $__internal_92cfa13d0a5ab00c3c86c56156e0c8ab9d4b617d75a0f604fb8c9fbc0cafe141->enter($__internal_92cfa13d0a5ab00c3c86c56156e0c8ab9d4b617d75a0f604fb8c9fbc0cafe141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_92cfa13d0a5ab00c3c86c56156e0c8ab9d4b617d75a0f604fb8c9fbc0cafe141->leave($__internal_92cfa13d0a5ab00c3c86c56156e0c8ab9d4b617d75a0f604fb8c9fbc0cafe141_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
