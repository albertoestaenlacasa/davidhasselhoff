<?php

/* base.html.twig */
class __TwigTemplate_de0ce297fc2445db8c417e765fa47437991b7a9ceb5a64a2b210ade1a98d682d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b773744028c2080e431d1623a10b0b2bfae8b7c4b3d1eb391a093d7a64a83031 = $this->env->getExtension("native_profiler");
        $__internal_b773744028c2080e431d1623a10b0b2bfae8b7c4b3d1eb391a093d7a64a83031->enter($__internal_b773744028c2080e431d1623a10b0b2bfae8b7c4b3d1eb391a093d7a64a83031_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_b773744028c2080e431d1623a10b0b2bfae8b7c4b3d1eb391a093d7a64a83031->leave($__internal_b773744028c2080e431d1623a10b0b2bfae8b7c4b3d1eb391a093d7a64a83031_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_af3c9d05d2b45b9e98041be9812e0e3a8f5f0b71ccfbc93b378e6bc454d123b0 = $this->env->getExtension("native_profiler");
        $__internal_af3c9d05d2b45b9e98041be9812e0e3a8f5f0b71ccfbc93b378e6bc454d123b0->enter($__internal_af3c9d05d2b45b9e98041be9812e0e3a8f5f0b71ccfbc93b378e6bc454d123b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_af3c9d05d2b45b9e98041be9812e0e3a8f5f0b71ccfbc93b378e6bc454d123b0->leave($__internal_af3c9d05d2b45b9e98041be9812e0e3a8f5f0b71ccfbc93b378e6bc454d123b0_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bc23b87785ccf564c4364cc4f981a330d98463e9d4c4b800ef7678c13cb0bc85 = $this->env->getExtension("native_profiler");
        $__internal_bc23b87785ccf564c4364cc4f981a330d98463e9d4c4b800ef7678c13cb0bc85->enter($__internal_bc23b87785ccf564c4364cc4f981a330d98463e9d4c4b800ef7678c13cb0bc85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_bc23b87785ccf564c4364cc4f981a330d98463e9d4c4b800ef7678c13cb0bc85->leave($__internal_bc23b87785ccf564c4364cc4f981a330d98463e9d4c4b800ef7678c13cb0bc85_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_50b24361e9a2f8efdc25e2976b539769942ca0813fae21d478b5173160993738 = $this->env->getExtension("native_profiler");
        $__internal_50b24361e9a2f8efdc25e2976b539769942ca0813fae21d478b5173160993738->enter($__internal_50b24361e9a2f8efdc25e2976b539769942ca0813fae21d478b5173160993738_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_50b24361e9a2f8efdc25e2976b539769942ca0813fae21d478b5173160993738->leave($__internal_50b24361e9a2f8efdc25e2976b539769942ca0813fae21d478b5173160993738_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_efbfe001d0522be3a92ae2cafd99a30d24eb785a4a6a4860f3ddf0e5935a263c = $this->env->getExtension("native_profiler");
        $__internal_efbfe001d0522be3a92ae2cafd99a30d24eb785a4a6a4860f3ddf0e5935a263c->enter($__internal_efbfe001d0522be3a92ae2cafd99a30d24eb785a4a6a4860f3ddf0e5935a263c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_efbfe001d0522be3a92ae2cafd99a30d24eb785a4a6a4860f3ddf0e5935a263c->leave($__internal_efbfe001d0522be3a92ae2cafd99a30d24eb785a4a6a4860f3ddf0e5935a263c_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
