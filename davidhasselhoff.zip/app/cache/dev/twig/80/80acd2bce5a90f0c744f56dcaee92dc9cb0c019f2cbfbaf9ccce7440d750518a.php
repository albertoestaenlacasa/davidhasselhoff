<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_776851a916febc01d0ad6cd39dd757cc0f956cc8b03be4e36f8513aa1aa5c22b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0905da536aee4465c08a32d0970dc2e6f573e84b80c28a1d09306b2aa568d8bb = $this->env->getExtension("native_profiler");
        $__internal_0905da536aee4465c08a32d0970dc2e6f573e84b80c28a1d09306b2aa568d8bb->enter($__internal_0905da536aee4465c08a32d0970dc2e6f573e84b80c28a1d09306b2aa568d8bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_0905da536aee4465c08a32d0970dc2e6f573e84b80c28a1d09306b2aa568d8bb->leave($__internal_0905da536aee4465c08a32d0970dc2e6f573e84b80c28a1d09306b2aa568d8bb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child) : ?>*/
/*     <?php echo $view['form']->row($child) ?>*/
/* <?php endforeach; ?>*/
/* */
