<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_0f2a75a9041bd0d00063c1ea73a339433e2da1f198617e65f7b71cc215d1373d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c68fcaf8f9cac0d5a1ace53024e1ba0b82b082e880e736681831a2681bdc1221 = $this->env->getExtension("native_profiler");
        $__internal_c68fcaf8f9cac0d5a1ace53024e1ba0b82b082e880e736681831a2681bdc1221->enter($__internal_c68fcaf8f9cac0d5a1ace53024e1ba0b82b082e880e736681831a2681bdc1221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_c68fcaf8f9cac0d5a1ace53024e1ba0b82b082e880e736681831a2681bdc1221->leave($__internal_c68fcaf8f9cac0d5a1ace53024e1ba0b82b082e880e736681831a2681bdc1221_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
