<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_97d3099c6cf64f146ceb512a23ebc3541a2866cf61fa3b1f18f00fe8eafd364b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4cfdd06d43ed230d72a30a73c55952485a161122e628565a49e4f34d2373e466 = $this->env->getExtension("native_profiler");
        $__internal_4cfdd06d43ed230d72a30a73c55952485a161122e628565a49e4f34d2373e466->enter($__internal_4cfdd06d43ed230d72a30a73c55952485a161122e628565a49e4f34d2373e466_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_4cfdd06d43ed230d72a30a73c55952485a161122e628565a49e4f34d2373e466->leave($__internal_4cfdd06d43ed230d72a30a73c55952485a161122e628565a49e4f34d2373e466_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
