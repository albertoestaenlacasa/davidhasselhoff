<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_3d7d3f4d6897fcd6efbede6bdba10f9bd23b14df5f82033bc847014ce3b280de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9a77e20873d02d9fe526816c51e5493f01d9e8322347a5192b86c6c5e64f657 = $this->env->getExtension("native_profiler");
        $__internal_d9a77e20873d02d9fe526816c51e5493f01d9e8322347a5192b86c6c5e64f657->enter($__internal_d9a77e20873d02d9fe526816c51e5493f01d9e8322347a5192b86c6c5e64f657_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_d9a77e20873d02d9fe526816c51e5493f01d9e8322347a5192b86c6c5e64f657->leave($__internal_d9a77e20873d02d9fe526816c51e5493f01d9e8322347a5192b86c6c5e64f657_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
