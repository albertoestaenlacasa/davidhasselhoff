<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_d37888231ee97a4e7016786271bb2dbef3a1f76082795b67acb0155746807bee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fa8128ac863ab82a2093b1c285aaceccedf662a68ad26b8c7b2240418a5814f = $this->env->getExtension("native_profiler");
        $__internal_8fa8128ac863ab82a2093b1c285aaceccedf662a68ad26b8c7b2240418a5814f->enter($__internal_8fa8128ac863ab82a2093b1c285aaceccedf662a68ad26b8c7b2240418a5814f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_8fa8128ac863ab82a2093b1c285aaceccedf662a68ad26b8c7b2240418a5814f->leave($__internal_8fa8128ac863ab82a2093b1c285aaceccedf662a68ad26b8c7b2240418a5814f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
