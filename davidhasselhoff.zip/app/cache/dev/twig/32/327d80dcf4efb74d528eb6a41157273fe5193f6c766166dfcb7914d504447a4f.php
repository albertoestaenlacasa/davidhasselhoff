<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_e0e83320532a2159e2ad3a5708924e222e906f95a50ed1c707cdb96be4e53bf4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_378202aa2d6147a341c417642cfd69ee9c502e7480dfaba332c1ba5adef2b689 = $this->env->getExtension("native_profiler");
        $__internal_378202aa2d6147a341c417642cfd69ee9c502e7480dfaba332c1ba5adef2b689->enter($__internal_378202aa2d6147a341c417642cfd69ee9c502e7480dfaba332c1ba5adef2b689_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_378202aa2d6147a341c417642cfd69ee9c502e7480dfaba332c1ba5adef2b689->leave($__internal_378202aa2d6147a341c417642cfd69ee9c502e7480dfaba332c1ba5adef2b689_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
