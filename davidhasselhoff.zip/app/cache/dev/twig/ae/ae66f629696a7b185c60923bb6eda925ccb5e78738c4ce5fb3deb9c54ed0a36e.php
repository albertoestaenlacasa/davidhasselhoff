<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_aa854d6fa5a24914ca9c5ddbf0def0bdc72132a4999be138cf4331e881054919 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51d070d3804b30d9b82cd658d9ac490edd18558cbce5643e3f35506e3bfbe591 = $this->env->getExtension("native_profiler");
        $__internal_51d070d3804b30d9b82cd658d9ac490edd18558cbce5643e3f35506e3bfbe591->enter($__internal_51d070d3804b30d9b82cd658d9ac490edd18558cbce5643e3f35506e3bfbe591_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_51d070d3804b30d9b82cd658d9ac490edd18558cbce5643e3f35506e3bfbe591->leave($__internal_51d070d3804b30d9b82cd658d9ac490edd18558cbce5643e3f35506e3bfbe591_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */
