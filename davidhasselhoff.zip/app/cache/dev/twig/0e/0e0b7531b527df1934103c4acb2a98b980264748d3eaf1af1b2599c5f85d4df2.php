<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_280675a91b62abf362733cb6fb1245a51e0c034f7c1b6a438cd20df50272acab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_370f8173d2f4ca1ba64947a797907fc38f890060956e3077a129e01cdb251a29 = $this->env->getExtension("native_profiler");
        $__internal_370f8173d2f4ca1ba64947a797907fc38f890060956e3077a129e01cdb251a29->enter($__internal_370f8173d2f4ca1ba64947a797907fc38f890060956e3077a129e01cdb251a29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_370f8173d2f4ca1ba64947a797907fc38f890060956e3077a129e01cdb251a29->leave($__internal_370f8173d2f4ca1ba64947a797907fc38f890060956e3077a129e01cdb251a29_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
