<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_b5f0fa03740836933bb6bff352c22bb8ed2e80bc05345b94e3694bbeab005620 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23b1768cf9cfc80f90390212fcc7ec1bb67ba04c0686fac88d684a4a60d40138 = $this->env->getExtension("native_profiler");
        $__internal_23b1768cf9cfc80f90390212fcc7ec1bb67ba04c0686fac88d684a4a60d40138->enter($__internal_23b1768cf9cfc80f90390212fcc7ec1bb67ba04c0686fac88d684a4a60d40138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_23b1768cf9cfc80f90390212fcc7ec1bb67ba04c0686fac88d684a4a60d40138->leave($__internal_23b1768cf9cfc80f90390212fcc7ec1bb67ba04c0686fac88d684a4a60d40138_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
