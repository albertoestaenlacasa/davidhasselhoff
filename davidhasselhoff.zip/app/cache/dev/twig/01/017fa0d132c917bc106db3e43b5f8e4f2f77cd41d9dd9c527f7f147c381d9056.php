<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_7180c957026773f7b488be12a674c531f5dcb91d48ec679e04928bd7b74a4721 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d541bacca8984ad11862cbe77003debb0d7853079684a9b6bbc8268bb6daabb = $this->env->getExtension("native_profiler");
        $__internal_9d541bacca8984ad11862cbe77003debb0d7853079684a9b6bbc8268bb6daabb->enter($__internal_9d541bacca8984ad11862cbe77003debb0d7853079684a9b6bbc8268bb6daabb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_9d541bacca8984ad11862cbe77003debb0d7853079684a9b6bbc8268bb6daabb->leave($__internal_9d541bacca8984ad11862cbe77003debb0d7853079684a9b6bbc8268bb6daabb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
