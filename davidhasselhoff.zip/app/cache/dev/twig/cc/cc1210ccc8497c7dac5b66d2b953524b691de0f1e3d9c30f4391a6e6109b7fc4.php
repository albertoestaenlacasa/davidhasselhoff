<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_b2c1103bfa3bd2db127fbf1f17568c9c0913d3d4a1b1843f971bbfb709649491 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c4cba28f4ec09cba8947ac880fee0ac96c8970f05f92680ba37b4a70665a5a8 = $this->env->getExtension("native_profiler");
        $__internal_4c4cba28f4ec09cba8947ac880fee0ac96c8970f05f92680ba37b4a70665a5a8->enter($__internal_4c4cba28f4ec09cba8947ac880fee0ac96c8970f05f92680ba37b4a70665a5a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_4c4cba28f4ec09cba8947ac880fee0ac96c8970f05f92680ba37b4a70665a5a8->leave($__internal_4c4cba28f4ec09cba8947ac880fee0ac96c8970f05f92680ba37b4a70665a5a8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
