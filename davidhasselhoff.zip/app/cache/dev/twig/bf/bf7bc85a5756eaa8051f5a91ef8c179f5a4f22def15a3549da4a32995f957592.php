<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_6571f89285312a50c9751530fe37508d83f6bca10ea5785a2f11297851dd7508 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f27b45153ecf6075af1125b1659d594368fbd98264693adc70cef603d348008 = $this->env->getExtension("native_profiler");
        $__internal_0f27b45153ecf6075af1125b1659d594368fbd98264693adc70cef603d348008->enter($__internal_0f27b45153ecf6075af1125b1659d594368fbd98264693adc70cef603d348008_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_0f27b45153ecf6075af1125b1659d594368fbd98264693adc70cef603d348008->leave($__internal_0f27b45153ecf6075af1125b1659d594368fbd98264693adc70cef603d348008_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
