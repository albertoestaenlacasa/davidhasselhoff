<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_a2cf02136b7a52b8f69eeb48025bde8dd3d9b58a5a3b489b4e9d72afa7fb5489 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ab4fad103ebbc0af77d5133699c797f7f2862b14cc843d9b4c04346ed850bbb = $this->env->getExtension("native_profiler");
        $__internal_9ab4fad103ebbc0af77d5133699c797f7f2862b14cc843d9b4c04346ed850bbb->enter($__internal_9ab4fad103ebbc0af77d5133699c797f7f2862b14cc843d9b4c04346ed850bbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ab4fad103ebbc0af77d5133699c797f7f2862b14cc843d9b4c04346ed850bbb->leave($__internal_9ab4fad103ebbc0af77d5133699c797f7f2862b14cc843d9b4c04346ed850bbb_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_10af97dddb83e6213411453e46ca527f748bb2e98de85e870bb28f224b13e0ec = $this->env->getExtension("native_profiler");
        $__internal_10af97dddb83e6213411453e46ca527f748bb2e98de85e870bb28f224b13e0ec->enter($__internal_10af97dddb83e6213411453e46ca527f748bb2e98de85e870bb28f224b13e0ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_10af97dddb83e6213411453e46ca527f748bb2e98de85e870bb28f224b13e0ec->leave($__internal_10af97dddb83e6213411453e46ca527f748bb2e98de85e870bb28f224b13e0ec_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_10a5879061f704d4780cbd704d92959ab9d413a4268bebe0064a259c74e9e542 = $this->env->getExtension("native_profiler");
        $__internal_10a5879061f704d4780cbd704d92959ab9d413a4268bebe0064a259c74e9e542->enter($__internal_10a5879061f704d4780cbd704d92959ab9d413a4268bebe0064a259c74e9e542_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_10a5879061f704d4780cbd704d92959ab9d413a4268bebe0064a259c74e9e542->leave($__internal_10a5879061f704d4780cbd704d92959ab9d413a4268bebe0064a259c74e9e542_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_b66c2167f6d0c0118c4d1c068b6b0e9e2fe56a9aada058c0b9f0c898d2164c69 = $this->env->getExtension("native_profiler");
        $__internal_b66c2167f6d0c0118c4d1c068b6b0e9e2fe56a9aada058c0b9f0c898d2164c69->enter($__internal_b66c2167f6d0c0118c4d1c068b6b0e9e2fe56a9aada058c0b9f0c898d2164c69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_b66c2167f6d0c0118c4d1c068b6b0e9e2fe56a9aada058c0b9f0c898d2164c69->leave($__internal_b66c2167f6d0c0118c4d1c068b6b0e9e2fe56a9aada058c0b9f0c898d2164c69_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
