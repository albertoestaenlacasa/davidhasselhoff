<?php

/* MyRecipesBundle:Default:index.html.twig */
class __TwigTemplate_10377700effda7e83912501081caa4bc24e4ec153951b21443b09527f9249994 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c74a74c237c756be6aee81b99208f7b4935919496a52eb843e1668b40f5f4a8 = $this->env->getExtension("native_profiler");
        $__internal_8c74a74c237c756be6aee81b99208f7b4935919496a52eb843e1668b40f5f4a8->enter($__internal_8c74a74c237c756be6aee81b99208f7b4935919496a52eb843e1668b40f5f4a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MyRecipesBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_8c74a74c237c756be6aee81b99208f7b4935919496a52eb843e1668b40f5f4a8->leave($__internal_8c74a74c237c756be6aee81b99208f7b4935919496a52eb843e1668b40f5f4a8_prof);

    }

    public function getTemplateName()
    {
        return "MyRecipesBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
