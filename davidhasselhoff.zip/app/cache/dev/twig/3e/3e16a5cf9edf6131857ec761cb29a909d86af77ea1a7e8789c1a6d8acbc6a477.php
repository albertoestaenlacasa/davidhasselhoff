<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_0132dc8fff80cfcca3f5fa999b672aedf5e381bab02233b324ee7963968ff38d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e90256c19c6695ea562af0452889d7e1235eb40f03e2907a15de724a625bea0 = $this->env->getExtension("native_profiler");
        $__internal_5e90256c19c6695ea562af0452889d7e1235eb40f03e2907a15de724a625bea0->enter($__internal_5e90256c19c6695ea562af0452889d7e1235eb40f03e2907a15de724a625bea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_5e90256c19c6695ea562af0452889d7e1235eb40f03e2907a15de724a625bea0->leave($__internal_5e90256c19c6695ea562af0452889d7e1235eb40f03e2907a15de724a625bea0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
