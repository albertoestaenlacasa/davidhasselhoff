<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_94afabf2e40bdac37e9f9cf9939664f4846d70599989988f0a988e493e8a32dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_64e9cbdee3056dcb1225b365b74f77d7e3bdafe8577de165450de9c8d5b2eb66 = $this->env->getExtension("native_profiler");
        $__internal_64e9cbdee3056dcb1225b365b74f77d7e3bdafe8577de165450de9c8d5b2eb66->enter($__internal_64e9cbdee3056dcb1225b365b74f77d7e3bdafe8577de165450de9c8d5b2eb66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_64e9cbdee3056dcb1225b365b74f77d7e3bdafe8577de165450de9c8d5b2eb66->leave($__internal_64e9cbdee3056dcb1225b365b74f77d7e3bdafe8577de165450de9c8d5b2eb66_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
