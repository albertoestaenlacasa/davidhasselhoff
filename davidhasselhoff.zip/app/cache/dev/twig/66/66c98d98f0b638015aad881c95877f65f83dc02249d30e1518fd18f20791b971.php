<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_cc86429d44edfac3ca5fdaee638f650df8517f04d9e021844fbeaa03073049c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ad987f0cb53a3a725d1f8b9ae27489d3e29197a622bc567bb7274a90469423d = $this->env->getExtension("native_profiler");
        $__internal_0ad987f0cb53a3a725d1f8b9ae27489d3e29197a622bc567bb7274a90469423d->enter($__internal_0ad987f0cb53a3a725d1f8b9ae27489d3e29197a622bc567bb7274a90469423d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_0ad987f0cb53a3a725d1f8b9ae27489d3e29197a622bc567bb7274a90469423d->leave($__internal_0ad987f0cb53a3a725d1f8b9ae27489d3e29197a622bc567bb7274a90469423d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
