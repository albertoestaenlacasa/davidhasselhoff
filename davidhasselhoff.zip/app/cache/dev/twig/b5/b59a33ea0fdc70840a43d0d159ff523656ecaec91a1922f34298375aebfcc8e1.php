<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_963438ec03cb3e13138dec17751ed5c3584cf7b446106dfa0b5e07b9330970f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c481e3d0a91abe44e7840adced08955cc9b0bc484df2dbfdd631391864d4d9fb = $this->env->getExtension("native_profiler");
        $__internal_c481e3d0a91abe44e7840adced08955cc9b0bc484df2dbfdd631391864d4d9fb->enter($__internal_c481e3d0a91abe44e7840adced08955cc9b0bc484df2dbfdd631391864d4d9fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_c481e3d0a91abe44e7840adced08955cc9b0bc484df2dbfdd631391864d4d9fb->leave($__internal_c481e3d0a91abe44e7840adced08955cc9b0bc484df2dbfdd631391864d4d9fb_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_4162f190f60ec4681f03dab10187d8633f830913adeb5f383304cc23b93fb405 = $this->env->getExtension("native_profiler");
        $__internal_4162f190f60ec4681f03dab10187d8633f830913adeb5f383304cc23b93fb405->enter($__internal_4162f190f60ec4681f03dab10187d8633f830913adeb5f383304cc23b93fb405_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_4162f190f60ec4681f03dab10187d8633f830913adeb5f383304cc23b93fb405->leave($__internal_4162f190f60ec4681f03dab10187d8633f830913adeb5f383304cc23b93fb405_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
