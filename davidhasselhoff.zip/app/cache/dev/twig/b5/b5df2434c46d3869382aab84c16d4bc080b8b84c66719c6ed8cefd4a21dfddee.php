<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_47b1c6139fe65cd48163c0222f70352fda12b16234b217d976532e4aea335fdb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76133b0d30b5130b8ef18ccc4e9f015af6f1b846db68a00447d2a72290de9391 = $this->env->getExtension("native_profiler");
        $__internal_76133b0d30b5130b8ef18ccc4e9f015af6f1b846db68a00447d2a72290de9391->enter($__internal_76133b0d30b5130b8ef18ccc4e9f015af6f1b846db68a00447d2a72290de9391_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_76133b0d30b5130b8ef18ccc4e9f015af6f1b846db68a00447d2a72290de9391->leave($__internal_76133b0d30b5130b8ef18ccc4e9f015af6f1b846db68a00447d2a72290de9391_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
