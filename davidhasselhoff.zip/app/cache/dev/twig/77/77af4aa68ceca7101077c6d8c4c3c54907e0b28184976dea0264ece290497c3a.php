<?php

/* @MyRecipes/Default/index.html.twig */
class __TwigTemplate_0bb149d7f104c64282e9244a7b1bfcd83eb553dcfccf4224999cc73fe090dace extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_98e924dcccae1750e36f24c78d95924146515eb7bb8370abdc322509a5e04bfa = $this->env->getExtension("native_profiler");
        $__internal_98e924dcccae1750e36f24c78d95924146515eb7bb8370abdc322509a5e04bfa->enter($__internal_98e924dcccae1750e36f24c78d95924146515eb7bb8370abdc322509a5e04bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@MyRecipes/Default/index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_98e924dcccae1750e36f24c78d95924146515eb7bb8370abdc322509a5e04bfa->leave($__internal_98e924dcccae1750e36f24c78d95924146515eb7bb8370abdc322509a5e04bfa_prof);

    }

    public function getTemplateName()
    {
        return "@MyRecipes/Default/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
