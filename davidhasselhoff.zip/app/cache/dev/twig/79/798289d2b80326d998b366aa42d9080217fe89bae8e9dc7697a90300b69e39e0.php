<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_37d21e947ce58abed6272f46fbf806b76ba3a9e192122e81985721ebfd780e4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c8c9680dacb1a6c947b1d39717170df69ca3950fd2a12de6ea652e82fdee1ab5 = $this->env->getExtension("native_profiler");
        $__internal_c8c9680dacb1a6c947b1d39717170df69ca3950fd2a12de6ea652e82fdee1ab5->enter($__internal_c8c9680dacb1a6c947b1d39717170df69ca3950fd2a12de6ea652e82fdee1ab5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_c8c9680dacb1a6c947b1d39717170df69ca3950fd2a12de6ea652e82fdee1ab5->leave($__internal_c8c9680dacb1a6c947b1d39717170df69ca3950fd2a12de6ea652e82fdee1ab5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
