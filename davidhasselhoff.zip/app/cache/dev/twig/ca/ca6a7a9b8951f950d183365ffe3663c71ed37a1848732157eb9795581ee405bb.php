<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_4815c5287b7a0aec53574b54d808e2d00cd417d49891bc35116fad954e2ef1bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2564512bf0091136c273571be2d6d35f39add307018b82b2f81b645033f2156e = $this->env->getExtension("native_profiler");
        $__internal_2564512bf0091136c273571be2d6d35f39add307018b82b2f81b645033f2156e->enter($__internal_2564512bf0091136c273571be2d6d35f39add307018b82b2f81b645033f2156e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_2564512bf0091136c273571be2d6d35f39add307018b82b2f81b645033f2156e->leave($__internal_2564512bf0091136c273571be2d6d35f39add307018b82b2f81b645033f2156e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
