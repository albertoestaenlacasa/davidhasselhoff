<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_0d5c7d9058b8c5afb70bceb8e73d79aeb3415a94ecf9de88a41d65b1691d697e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60c4a512fbe8b41f43fbbe13eab7b158704e2dc8eab7b6ef5d596cc068867a17 = $this->env->getExtension("native_profiler");
        $__internal_60c4a512fbe8b41f43fbbe13eab7b158704e2dc8eab7b6ef5d596cc068867a17->enter($__internal_60c4a512fbe8b41f43fbbe13eab7b158704e2dc8eab7b6ef5d596cc068867a17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_60c4a512fbe8b41f43fbbe13eab7b158704e2dc8eab7b6ef5d596cc068867a17->leave($__internal_60c4a512fbe8b41f43fbbe13eab7b158704e2dc8eab7b6ef5d596cc068867a17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
