<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_a975bc5054c582d9de913a2c03f33a80afb6a34e221bd22e2ac9d9a4b9cce9ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b6963c06a2ab661573a22c37d2726893f78b2cdd0e7fe491f7343797dacd804a = $this->env->getExtension("native_profiler");
        $__internal_b6963c06a2ab661573a22c37d2726893f78b2cdd0e7fe491f7343797dacd804a->enter($__internal_b6963c06a2ab661573a22c37d2726893f78b2cdd0e7fe491f7343797dacd804a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_b6963c06a2ab661573a22c37d2726893f78b2cdd0e7fe491f7343797dacd804a->leave($__internal_b6963c06a2ab661573a22c37d2726893f78b2cdd0e7fe491f7343797dacd804a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
