<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_047c096d4a9f8b143b6641d04dcf5a8385b4913cce22f3527e65a00268450671 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1416ecbf52bec2b92fa1e55236b0f6945820e064d0e523f1861b52b47434b14d = $this->env->getExtension("native_profiler");
        $__internal_1416ecbf52bec2b92fa1e55236b0f6945820e064d0e523f1861b52b47434b14d->enter($__internal_1416ecbf52bec2b92fa1e55236b0f6945820e064d0e523f1861b52b47434b14d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_1416ecbf52bec2b92fa1e55236b0f6945820e064d0e523f1861b52b47434b14d->leave($__internal_1416ecbf52bec2b92fa1e55236b0f6945820e064d0e523f1861b52b47434b14d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
