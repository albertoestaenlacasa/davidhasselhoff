<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_a678d0e09ffaac28c38e70e2e2c3b66dbda4cedbf1fc01cc555b771ee73c0135 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7dc1bc9bbf34bb917d005ef5445cea7ad87641fd05f218d55d353e23ded31cd = $this->env->getExtension("native_profiler");
        $__internal_d7dc1bc9bbf34bb917d005ef5445cea7ad87641fd05f218d55d353e23ded31cd->enter($__internal_d7dc1bc9bbf34bb917d005ef5445cea7ad87641fd05f218d55d353e23ded31cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_d7dc1bc9bbf34bb917d005ef5445cea7ad87641fd05f218d55d353e23ded31cd->leave($__internal_d7dc1bc9bbf34bb917d005ef5445cea7ad87641fd05f218d55d353e23ded31cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
