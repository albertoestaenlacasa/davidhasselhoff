<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_f701412df1c59b8f3849213b53d1a7d7a1f19354230a1d6f7883ab3fb315452b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fde1dbaf3db52e4d0470ff09fcce0c501b0573194eab85dbd38a3aad324fb54 = $this->env->getExtension("native_profiler");
        $__internal_9fde1dbaf3db52e4d0470ff09fcce0c501b0573194eab85dbd38a3aad324fb54->enter($__internal_9fde1dbaf3db52e4d0470ff09fcce0c501b0573194eab85dbd38a3aad324fb54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_9fde1dbaf3db52e4d0470ff09fcce0c501b0573194eab85dbd38a3aad324fb54->leave($__internal_9fde1dbaf3db52e4d0470ff09fcce0c501b0573194eab85dbd38a3aad324fb54_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
