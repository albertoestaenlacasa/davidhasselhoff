<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_601195f368b362e93dd29a95d8272a8d87a2d6b0d05bebef5211afcb66c4db48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be2156d353218c33a0ce531ce70b19043ab55fbcbaae3f75190f26e8eedf5d2e = $this->env->getExtension("native_profiler");
        $__internal_be2156d353218c33a0ce531ce70b19043ab55fbcbaae3f75190f26e8eedf5d2e->enter($__internal_be2156d353218c33a0ce531ce70b19043ab55fbcbaae3f75190f26e8eedf5d2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_be2156d353218c33a0ce531ce70b19043ab55fbcbaae3f75190f26e8eedf5d2e->leave($__internal_be2156d353218c33a0ce531ce70b19043ab55fbcbaae3f75190f26e8eedf5d2e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
