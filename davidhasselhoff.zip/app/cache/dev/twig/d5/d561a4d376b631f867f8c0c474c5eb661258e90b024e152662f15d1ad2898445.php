<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_01349c3f442c74ed8cd387655e9eb54281434990d1bd623630dbf383d5d40c77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e2aef535fe9a418e899c1800ad1d4c7856c77347842c83b833644cb1221eae9 = $this->env->getExtension("native_profiler");
        $__internal_2e2aef535fe9a418e899c1800ad1d4c7856c77347842c83b833644cb1221eae9->enter($__internal_2e2aef535fe9a418e899c1800ad1d4c7856c77347842c83b833644cb1221eae9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_2e2aef535fe9a418e899c1800ad1d4c7856c77347842c83b833644cb1221eae9->leave($__internal_2e2aef535fe9a418e899c1800ad1d4c7856c77347842c83b833644cb1221eae9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
