<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_514d8ae54dcd650d3439eb21bac5f8216803e2cd4c1604eba3e3dd5d5a915bd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d58e0c6aaba5564fec53c2a5478678a39dfb9ccb0e8e8681099d44b82f0e241 = $this->env->getExtension("native_profiler");
        $__internal_5d58e0c6aaba5564fec53c2a5478678a39dfb9ccb0e8e8681099d44b82f0e241->enter($__internal_5d58e0c6aaba5564fec53c2a5478678a39dfb9ccb0e8e8681099d44b82f0e241_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_5d58e0c6aaba5564fec53c2a5478678a39dfb9ccb0e8e8681099d44b82f0e241->leave($__internal_5d58e0c6aaba5564fec53c2a5478678a39dfb9ccb0e8e8681099d44b82f0e241_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
