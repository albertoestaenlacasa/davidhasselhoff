<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_3783289bbce22f6d0935108d7ad5f6b3540a81d01c95701cb4507acba161d1cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_621babdeef8692d922e64227a5f1f8951f509cf99614e1d50b559b39b6cba45d = $this->env->getExtension("native_profiler");
        $__internal_621babdeef8692d922e64227a5f1f8951f509cf99614e1d50b559b39b6cba45d->enter($__internal_621babdeef8692d922e64227a5f1f8951f509cf99614e1d50b559b39b6cba45d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_621babdeef8692d922e64227a5f1f8951f509cf99614e1d50b559b39b6cba45d->leave($__internal_621babdeef8692d922e64227a5f1f8951f509cf99614e1d50b559b39b6cba45d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
