<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_fc5d0a3b60af8d5489046d4a8bc170d80d79be58f5eca2d9c98f71b2ebfed544 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f38fe587e9611079d0b525ccd755f60470dc3e6e4ff0bf2a5b092e0d9378b3e8 = $this->env->getExtension("native_profiler");
        $__internal_f38fe587e9611079d0b525ccd755f60470dc3e6e4ff0bf2a5b092e0d9378b3e8->enter($__internal_f38fe587e9611079d0b525ccd755f60470dc3e6e4ff0bf2a5b092e0d9378b3e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_f38fe587e9611079d0b525ccd755f60470dc3e6e4ff0bf2a5b092e0d9378b3e8->leave($__internal_f38fe587e9611079d0b525ccd755f60470dc3e6e4ff0bf2a5b092e0d9378b3e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($widget == 'single_text'): ?>*/
/*     <?php echo $view['form']->block($form, 'form_widget_simple'); ?>*/
/* <?php else: ?>*/
/*     <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*         <?php echo $view['form']->widget($form['date']).' '.$view['form']->widget($form['time']) ?>*/
/*     </div>*/
/* <?php endif ?>*/
/* */
