<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_bf8c625ac6d06250092cf6aebc021a588a5095ccbeaf7d8fd022d715195ff759 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd3aee959f29f1a4af06ea7cb136739b8f45e5e69cf61293244a338949d87100 = $this->env->getExtension("native_profiler");
        $__internal_dd3aee959f29f1a4af06ea7cb136739b8f45e5e69cf61293244a338949d87100->enter($__internal_dd3aee959f29f1a4af06ea7cb136739b8f45e5e69cf61293244a338949d87100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_dd3aee959f29f1a4af06ea7cb136739b8f45e5e69cf61293244a338949d87100->leave($__internal_dd3aee959f29f1a4af06ea7cb136739b8f45e5e69cf61293244a338949d87100_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
