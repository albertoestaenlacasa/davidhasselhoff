<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_4ae627c5750e2e2674618a24293a2fed89efafe3566fc81b1560b375d709b368 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e1c4005f7aaf1fd3245ac076bdc40b947e6d74d8aa56f9aeda1e05e6a37026a = $this->env->getExtension("native_profiler");
        $__internal_3e1c4005f7aaf1fd3245ac076bdc40b947e6d74d8aa56f9aeda1e05e6a37026a->enter($__internal_3e1c4005f7aaf1fd3245ac076bdc40b947e6d74d8aa56f9aeda1e05e6a37026a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_3e1c4005f7aaf1fd3245ac076bdc40b947e6d74d8aa56f9aeda1e05e6a37026a->leave($__internal_3e1c4005f7aaf1fd3245ac076bdc40b947e6d74d8aa56f9aeda1e05e6a37026a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
