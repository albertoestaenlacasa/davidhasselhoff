<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_f82e44a73aefd7e93f9f9c7f3e7a538867e66f7eebb40dd352fd68a8a149ca71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc404299dd65c1480193382cf953ce8cee0f6c041165d9c26f2a9148614261f7 = $this->env->getExtension("native_profiler");
        $__internal_fc404299dd65c1480193382cf953ce8cee0f6c041165d9c26f2a9148614261f7->enter($__internal_fc404299dd65c1480193382cf953ce8cee0f6c041165d9c26f2a9148614261f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_fc404299dd65c1480193382cf953ce8cee0f6c041165d9c26f2a9148614261f7->leave($__internal_fc404299dd65c1480193382cf953ce8cee0f6c041165d9c26f2a9148614261f7_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
