<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_2c96588ab99db7caa2bc51e16fc2066d9731f5e7e63de8bffc18b7fe42d8cfc0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_854db36d284a10fdc48f121d216917371ec4aef35f24a7490371c0cda3c33940 = $this->env->getExtension("native_profiler");
        $__internal_854db36d284a10fdc48f121d216917371ec4aef35f24a7490371c0cda3c33940->enter($__internal_854db36d284a10fdc48f121d216917371ec4aef35f24a7490371c0cda3c33940_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_854db36d284a10fdc48f121d216917371ec4aef35f24a7490371c0cda3c33940->leave($__internal_854db36d284a10fdc48f121d216917371ec4aef35f24a7490371c0cda3c33940_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
