<?php

/* MyRecipesBundle:Default:index.html.twig */
class __TwigTemplate_aee6111505325f755f0e12c47c9554868d8d622ef6a7f1b5ba60116f8b10ea7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
    }

    public function getTemplateName()
    {
        return "MyRecipesBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* Hello World!*/
/* */
